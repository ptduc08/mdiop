<?php
// Heading
$_['heading_title']    = 'Tổng Chi ';

// Text
$_['text_total']       = 'Tổng số đơn hàng';
$_['text_success']     = 'Thành công: bạn đã sửa Tổng Chi !';
$_['text_edit']        = 'Chỉnh sửa Sub-Total Total';

// Entry
$_['entry_status']     = 'Tình trạng:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi Tổng Chi !';
?>