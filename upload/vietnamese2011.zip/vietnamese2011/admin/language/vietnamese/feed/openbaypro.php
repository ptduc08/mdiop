<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Modules';
$_['text_installed'] = 'OpenBay Pro module đã được cài đặt. Nó nằm trong mục Phần mở rộng -> OpenBay Pro';