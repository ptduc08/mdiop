<?php
// Heading
$_['heading_title']          = 'SEO Images';
$_['text_success']          = 'Success: You have successfully saved parameters!';

// Error 
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify SEO Images!';

?>