<?php
// Heading
$_['heading_title']    = 'Auto Internal Links';

// Text 
$_['text_success']     = 'Thành công: Bạn đã lưu Auto Internal Links!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi Auto Internal Links!';
?>