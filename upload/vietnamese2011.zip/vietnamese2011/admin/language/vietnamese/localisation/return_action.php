<?php
// Heading
$_['heading_title']    = 'Quay lại công việc';

// Text
$_['text_success']     = 'Thành công: Bạn đã sửa đổi các công việc trở lại!';
$_['text_list']        = 'Return Action List';
$_['text_add']         = 'Add Return Action';
$_['text_edit']        = 'Edit Return Action';

// Column
$_['column_name']      = 'Tên công việc Trở lại';
$_['column_action']    = 'Thao tác';

// Entry
$_['entry_name']       = 'Tên công việc Trở lại:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi các công việc trở lại!';
$_['error_name']       = 'Tên Quay trở lại công việc phải có từ 3 đến 32 ký tự!';
$_['error_return']     = 'Cảnh báo: Công việc trở lại này không thể đã bị xóa khi nó hiện thời được gán Tới %s sản phẩm Trở lại.!';
?>