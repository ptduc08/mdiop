<?php
// Heading
$_['heading_title'] = 'Lịch sử lỗi';

// Text
$_['text_list']        = 'Errors List';
$_['text_success']  = 'Thành công: Bạn đã xóa lịch sử lỗi!';

// Error
$_['error_warning']	   = 'Warning: Your error log file %s is %s!';
$_['error_permission'] = 'Warning: You do not have permission to clear error log!';
?>