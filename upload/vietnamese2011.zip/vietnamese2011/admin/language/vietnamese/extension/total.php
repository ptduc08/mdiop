<?php
// Heading
$_['heading_title']     = 'Tổng đơn hàng';

// Text
$_['text_success']      = 'Success: Bạn đã thay đổi tổng thể!';
$_['text_list']         = 'Danh sách đơn hàng tổng';
$_['text_uninstall']    = 'Gỡ bỏ';

// Column
$_['column_name']       = 'Tổng đơn hàng';
$_['column_status']     = 'Trạng thái';
$_['column_sort_order'] = 'Thứ tự';
$_['column_action']     = 'Thao tác';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền sửa đổi tổng đơn hàng!';
?>