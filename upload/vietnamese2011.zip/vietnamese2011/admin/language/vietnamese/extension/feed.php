<?php
// Heading
$_['heading_title']      = 'Feeds sản phẩm';

// Text
$_['text_success']     = 'Success: You have modified feeds!';
$_['text_install']       = 'Cài đặt';
$_['text_list']        = 'Feed List';
$_['text_uninstall']     = 'Gỡ bỏ';

// Column
$_['column_name']        = 'Tên nguồn cấp';
$_['column_status']      = 'Trạng thái';
$_['column_action']      = 'Thao tác';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền sửa đổi nguồn cung cấp!';
?>