<?php
$_['lang_btn_status']           = 'Change status';
$_['lang_order_channel']        = 'Order Channel';
$_['lang_confirmed']            = 'orders have been marked';
$_['lang_no_orders']            = 'No orders selected for update';
$_['lang_confirm_title']        = 'Review bulk status update';
$_['lang_confirm_change_text']  = 'Changing order status to';
$_['lang_column_addtional']     = 'Additional info';
$_['lang_column_comments']      = 'Comments';
$_['lang_column_notify']        = 'Notify';
$_['lang_carrier']              = 'Carrier';
$_['lang_tracking']             = 'Tracking';
$_['lang_other']                = 'Other';
$_['lang_refund_reason']        = 'Refund reason';
$_['lang_refund_message']       = 'Refund message';
$_['lang_update']               = 'Update';
$_['lang_cancel']               = 'Cancel';
$_['lang_e_ajax_1']             = 'A play order is missing a refund message!';
$_['lang_e_ajax_2']             = 'A play order is missing tracking info!';
$_['lang_e_ajax_3']             = 'An Amazon order is missing an "Other Carrier" entry!';
$_['lang_title_order_update']   = 'Bulk order update';
