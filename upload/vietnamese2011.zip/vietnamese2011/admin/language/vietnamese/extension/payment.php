<?php
// Heading
$_['heading_title']      = 'Thanh toán';

// Text
$_['text_success']      = 'Success: You have modified payments!';
$_['text_list']         = 'Payment List';
$_['text_install']       = 'Cài đặt';
$_['text_uninstall']     = 'Gỡ bỏ';

// Column
$_['column_name']        = 'Phương thức thanh toán';
$_['column_status']      = 'Trạng thái';
$_['column_sort_order']  = 'Thứ tự';
$_['column_action']      = 'Thao tác';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền sửa đổi các khoản thanh toán!';
?>