<?php
// Heading
$_['heading_title']    = 'Báo cáo mã giảm giá';
// Text
$_['text_list']        = 'Coupon List';

// Column
$_['column_name']      = 'Tên phiếu';
$_['column_code']      = 'Mã';
$_['column_orders']    = 'Đơn hàng';
$_['column_total']     = 'Tổng cộng';
$_['column_action']    = 'Thao tác';

// Entry
$_['entry_date_start'] = 'Ngày bắt đầu:';
$_['entry_date_end']   = 'Ngày kết thúc:';
?>