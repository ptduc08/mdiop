<?php
// Heading
$_['heading_title']  = 'Các sản phẩm đã xem';

// Text
$_['text_success']   = 'Thành công: Bạn đã thiết lập lại các báo cáo sản phẩm đã xem!';

// Column
$_['column_name']    = 'Tên sản phẩm';
$_['column_model']   = 'Model';
$_['column_viewed']  = 'Lượt xem';
$_['column_percent'] = 'Phần trăm';
?>