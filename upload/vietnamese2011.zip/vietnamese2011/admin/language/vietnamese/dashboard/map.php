<?php
// Heading
$_['heading_title'] = 'Bản đồ thế giới';

$_['text_order']    = 'Đơn hàng';
$_['text_sale']     = 'Kết quả kinh doanh';