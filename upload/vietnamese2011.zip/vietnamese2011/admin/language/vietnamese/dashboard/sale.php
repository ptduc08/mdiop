<?php
// Heading
$_['heading_title'] = 'Tổng thể kinh doanh';

// Text
$_['text_view']     = 'Xem chi tiết...';