<?php
// Heading
$_['heading_title'] = 'Lượng người trực tuyến';

// Text
$_['text_view']     = 'Xem chi tiết...';