<?php
// Heading
$_['heading_title'] = 'Phân tích số liệu bán hàng';

// Text
$_['text_order']    = 'Đơn hàng';
$_['text_customer'] = 'Khách hàng';
$_['text_day']      = 'Trong ngày';
$_['text_week']     = 'Trong tuần';
$_['text_month']    = 'Theo tháng';
$_['text_year']     = 'Theo năm';