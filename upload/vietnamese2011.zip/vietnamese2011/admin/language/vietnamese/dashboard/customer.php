<?php
// Heading
$_['heading_title'] = 'Tổng thể khách hàng';

// Text
$_['text_view'] = 'Xem chi tiết...';