<?php
// Text
$_['text_footer'] = 'iMart - Opencart';
$_['text_version'] 	= 'Version %s';
?>