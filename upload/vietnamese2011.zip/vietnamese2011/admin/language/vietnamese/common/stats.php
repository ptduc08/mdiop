<?php
$_['text_complete_status']   = 'Đơn hàng đã hoàn thành'; 
$_['text_processing_status'] = 'Đơn hàng đang xử lý'; 
$_['text_other_status']      = 'Các tình trạng khác'; 