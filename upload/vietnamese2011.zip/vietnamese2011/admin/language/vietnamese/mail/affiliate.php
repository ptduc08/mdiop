<?php
// Text
$_['text_approve_subject']      = '%s - Tài khoản đại lý của bạn đã được kích hoạt!';
$_['text_approve_welcome']      = 'Chào mừng và cảm ơn bạn đã đăng ký tại %s!';
$_['text_approve_login']        = 'tài khoản của bạn đã được tạo ra và bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu bằng cách truy cập trang web của chúng tôi hoặc tại URL sau:';
$_['text_approve_services']     = 'Sau khi đăng nhập, bạn sẽ có thể tạo ra các mã số theo dõi, theo dõi việc thanh toán hoa hồng và chỉnh sửa thông tin tài khoản của bạn.';
$_['text_approve_thanks']       = 'Cảm ơn,';
$_['text_transaction_subject']  = '%s - hoa hồng đại lý';
$_['text_transaction_received'] = 'Bạn đã nhận được %s hoa hồng!';
$_['text_transaction_total']    = 'tổng số tiền hoa hồng của bạn bây giờ là %s.';
?>