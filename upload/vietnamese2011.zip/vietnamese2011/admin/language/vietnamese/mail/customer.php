<?php
// Text
$_['text_approve_subject']      = '%s - Tài khoản của bạn đã được kích hoạt!';
$_['text_approve_welcome']      = 'Chào mừng và cảm ơn bạn đã đăng ký tại %s!';
$_['text_approve_login']        = 'tài khoản của bạn đã được tạo ra và bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu bằng cách truy cập trang web của chúng tôi hoặc tại URL sau:';
$_['text_approve_services']     = 'Sau khi đăng nhập, bạn sẽ có thể truy cập các dịch vụ khác bao gồm xem xét đơn đặt hàng qua, in hóa đơn, chỉnh sửa thông tin tài khoản của bạn.';
$_['text_approve_thanks']       = 'Cảm ơn,';
$_['text_transaction_subject']  = '%s - Tài khoản tín dụng';
$_['text_transaction_received'] = 'Bạn đã nhận được %s tín dụng!';
$_['text_transaction_total']    = 'Tổng số tiền tín dụng của bạn bây giờ là %s.' . "\n\n" . 'tài khoản tín dụng của bạn sẽ được tự động trừ vào mua hàng tiếp theo của bạn.';
$_['text_reward_subject']       = '%s -  Điểm thưởng';
$_['text_reward_received']      = 'Bạn đã nhận được %s Điểm thưởng!';
$_['text_reward_total']         = 'tổng số điểm thưởng của bạn bây giờ là %s.';
?>