<?php

// Text
$_['text_agree']                     = 'I have read and agree to the <a class="fancybox" href="%s" alt="%s" target="_blank"><b>%s</b></a>';

?>