<?php
//Text
$_['paid_on_amazon_text'] = 'Paid on Amazon';
$_['text_paid_amazon'] 			= 'Paid on Amazon';
$_['text_total_shipping'] 		= 'Shipping';
$_['text_total_shipping_tax'] 	= 'Shipping tax';
$_['text_total_giftwrap'] 		= 'Gift wrap';
$_['text_total_giftwrap_tax'] 	= 'Gift wrap tax';
$_['text_total_sub'] 			= 'Sub-total';
$_['text_tax'] 					= 'Tax';
$_['text_total'] 				= 'Total';
//Order totals
$_['shipping_text'] = 'Shipping';
$_['shipping_tax_text'] = 'Shipping tax';
$_['gift_wrap_text'] = 'Gift Wrap';
$_['gift_wrap_tax_text'] = 'Gift Wrap tax';
$_['sub_total_text'] = 'Sub-Total';
$_['tax_text'] = 'Tax';
$_['total_text'] = 'Total';
?>