<?php
// Text
$_['text_subject']  = '%s - Mật khẩu mới';
$_['text_greeting'] = 'Yêu cầu mật khẩu mới được gửi từ %s.';
$_['text_password'] = 'Mật khẩu mới của bạn là:';
?>