<?php
// Heading 
$_['heading_title']   = 'Quản lý tải về';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_downloads']  = 'Tải về';
$_['text_order']      = 'Mã đơn hàng:';
$_['text_date_added'] = 'Ngày tạo:';
$_['text_name']       = 'Tên:';
$_['text_remaining']  = 'Còn lại:';
$_['text_size']       = 'Kích thước:';
$_['text_download']   = 'Tải về';
$_['text_empty']      = 'Bạn không có đơn hàng nào có thể tải về!';
$_['text_empty']        = 'Bạn đã không thực hiện bất kỳ đơn đặt hàng có thể tải về trước đó!';

// Column
$_['column_order_id']   = 'Order ID';
$_['column_name']       = 'Tên';
$_['column_size']       = 'Kích thước';
$_['column_date_added'] = 'Date Added';

?>