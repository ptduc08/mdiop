<?php
// Heading  
$_['heading_title']          = 'Bossthemes Compare';

// Text
$_['text_title']             = 'Product added to compare';
$_['text_thumb']             = '<img src="%s" alt="" />';
$_['text_success']           = 'Success: You have added <a href="%s">%s</a> to your <a href="%s" class="cart">product comparison</a>';
$_['text_items']             = '%s item(s) - %s';
$_['text_compare']   	   	 = 'Product Compare (%s)';

// Error
$_['error_required']         = '%s required!';	

?>