<?php
// Text
$_['text_search'] = 'Tìm kiếm';