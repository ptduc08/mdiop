<?php
#############################################################################
#  Adpatations for OpenCart 1.4.9 from Hildebrando 31.8.2010
#  Original developed by  Somsak2004, web: www.somsak2004.net email: sanma2001@hotmail.com
#  
#############################################################################
// Heading 
$_['heading_title']  = 'Movie';
$_['youtube_extension']  = '&hl=en_US&fs=1&';
?>