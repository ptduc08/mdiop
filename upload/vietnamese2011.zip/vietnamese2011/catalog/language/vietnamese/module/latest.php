<?php
// Heading 
$_['heading_title'] = 'Sản phẩm mới nhất';

// Text
$_['text_reviews']  = 'Dựa trên %s đánh giá.'; 
$_['text_tax']      = 'Ex Tax:';
?>