<?php
$_['heading_title']     = 'Tags từ khóa';

$_['text_notags']       = 'Không có tag từ';
$_['text_href_title']   = 'items tagged with';
?>