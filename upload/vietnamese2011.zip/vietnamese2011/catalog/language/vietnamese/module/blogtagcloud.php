<?php
//-----------------------------------------------------
// TagCloud for Opencart v1.5.3    
// Created by villagedefrance                          
// contact@villagedefrance.net                                    
//-----------------------------------------------------

// Heading
$_['heading_title']  	= 'Blog Tag Cloud';

// Messages
$_['text_notags']  		= 'No tags available';
?>