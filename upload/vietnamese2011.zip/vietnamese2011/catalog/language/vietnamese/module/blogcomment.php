<?php
$_['heading_title']     = 'Ý kiến gần đây';

$_['text_comment_on']   = 'bật';
?>