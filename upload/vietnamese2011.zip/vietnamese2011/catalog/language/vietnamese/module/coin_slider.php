<?php
// Heading 
$_['heading_title'] 		= 'Coin Slider';

// Text
$_['text_prev'] 	= 'prev';
$_['text_next']     = 'next';
?>
