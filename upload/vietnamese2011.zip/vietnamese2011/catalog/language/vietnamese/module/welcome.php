<?php
$_['heading_title'] = 'Chào mừng đến với %s';
?>