<?php
// Heading
$_['heading_title'] = 'Bài đã đăng';
?>