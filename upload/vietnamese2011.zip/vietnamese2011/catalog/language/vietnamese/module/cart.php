﻿<?php
// Heading 
$_['heading_title'] = 'Giỏ Hàng';

// Text
$_['text_items']    = '%s item(s) - %s';
$_['text_empty']    = 'Giỏ hàng đang trống!';
$_['text_cart']     = 'Xem giỏ hàng';
$_['text_checkout'] = 'Thanh toán';
?>