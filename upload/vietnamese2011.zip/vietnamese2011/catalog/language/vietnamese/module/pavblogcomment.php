<?php
// Heading 
$_['heading_title'] = 'Latest Comments';

  $_['text_postedby'] = 'Posted By';
?>