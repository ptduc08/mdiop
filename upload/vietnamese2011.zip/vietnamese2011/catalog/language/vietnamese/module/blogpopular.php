<?php
$_['heading_title']     = 'Bái viết tiêu biểu';
?>