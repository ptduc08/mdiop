<?php
// ----------------------------------
// Pro Category Menu for OpenCart 
// By Best-Byte
// www.best-byte.com
// ----------------------------------

// Heading
$_['heading_title'] = 'Danh mục sản phẩm';
?>