<?php
// Heading
$_['heading_title'] = 'Products By Alphabet';
?>