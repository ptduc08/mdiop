<?php
// Text
$_['text_all_reviews']  = 'Read all reviews'; 
?>