<?php
// Heading 
$_['heading_title'] = 'Latest';

// Text
$_['text_latest']  = 'Latest Blog'; 
$_['text_mostviewed']  = 'Most Viewed'; 
$_['text_featured']  = 'Featured'; 
$_['text_bestseller']  = 'Best Seller'; 
$_['entry_show_readmore'] = 'Show Readmore' ;
$_['text_readmore'] = 'Read more' ;
?>