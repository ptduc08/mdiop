<?php
// Heading 
$_['heading_title'] = 'Blog Category';

// Text
$_['text_latest']  = 'Latest'; 
$_['text_mostviewed']  = 'Most Viewed'; 
$_['text_featured']  = 'Featured'; 
$_['text_bestseller']  = 'Best Seller'; 
?>