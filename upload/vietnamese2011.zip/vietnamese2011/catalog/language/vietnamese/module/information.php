﻿<?php
// Heading 
$_['heading_title'] = 'Thông tin';

// Text
$_['text_contact']  = 'Liên Hệ';
$_['text_sitemap']  = 'Sơ đồ trang';
?>