<?php
// Heading 
$_['heading_title']    = 'Văn phẩm cùng danh mục';

?>
