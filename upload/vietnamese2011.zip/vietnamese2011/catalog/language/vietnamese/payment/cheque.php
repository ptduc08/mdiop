<?php
// Text
$_['text_title']       = 'Séc / Hướng dẫn đặt hàng';
$_['text_instruction'] = 'Séc / Giá thành đơn hàng';
$_['text_payable']     = 'Đặt tiền phải trả cho: ';
$_['text_address']     = 'Gửi cho: ';
$_['text_payment']     = 'Đặt hàng của bạn sẽ chưa đưa đi cho đến khi chúng tôi nhận được thanh toán.';
?>