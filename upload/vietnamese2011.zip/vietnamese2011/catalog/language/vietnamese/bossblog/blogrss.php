<?php
// Heading
$_['heading_title']     = 'RSS Boss Blog';

?>