<?php
// Text
$_['text_error']        = 'Blog Category not found!';
$_['text_empty']        = 'There are no Articles to list in this blog category.';
$_['text_bossblog']        = 'Blog';
$_['text_sort']         = 'Sort By:';
$_['text_default']      = 'Default';
$_['text_name_asc']     = 'Name (A - Z)';
$_['text_name_desc']    = 'Name (Z - A)';
$_['text_date_asc']    = 'Date Added (Old &gt; New)';
$_['text_date_desc']   = 'Date Added (New &gt; Old)';
$_['text_comment_asc']   = 'Comment (Lowest)';
$_['text_comment_desc']  = 'Comment (Highest)';
$_['text_limit']        = 'Show:';
$_['text_sub_category']        = 'Refine Search';
$_['text_display']      = 'Display:';
$_['text_list']         = 'List';
$_['text_grid']         = 'Grid';
?>