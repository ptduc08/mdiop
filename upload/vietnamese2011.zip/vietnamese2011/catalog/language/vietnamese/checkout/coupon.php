<?php
// Heading
$_['heading_title'] = 'Sử dụng phiếu giảm giá';

// Text
$_['text_success']  = 'Thành công: Phiếu giảm giá của bạn đã được áp dụng!';

// Entry
$_['entry_coupon']  = 'Nhập mã phiếu giảm giá';

// Error
$_['error_coupon']  = 'Cảnh báo: Mã phiếu giảm giá không hợp lệ hoặc đã quá hạn!';
$_['error_empty']   = 'Cảnh báo: Vui lòng nhập mã phiếu giảm giá!';